# Unity Logistique

Première version PWA de gestion du matériel de sécurité privée.

## Fonctionnalités
- Agents : nom, prénom, matricule, site
- Stock : numéro unique, type, état, statut, agent
- Remise : sélection du matériel disponible, photo avant, commentaire, signatures
- Restitution : matériel attribué, photo après, état, nouveau statut, signatures
- Historique conservé localement
- Interface mobile responsive
- Manifest PWA

## Mise en ligne
Le dossier peut être publié sur un hébergeur statique compatible avec les PWA.
